AWPI Phi/RH Lean — Rocq-matched v0.1.4
========================================

Platform
--------
Native Windows CMD. Do not use WSL for this package.
Pinned toolchain: Lean 4.33.0 / Mathlib v4.33.0.

What this proves
----------------
The Lean theorem spine is matched to the Rocq v0.30 split:
  Forward: C -> RH
  Reverse: B /\ RH -> C
  Under B: C <-> RH

The numbered Lean spine includes PHIRH240, 242-244, 264, 270-276, 283-296.
No `sorry`, `admit`, or `axiom` is intended in the package.

Install Lean (once)
-------------------
Prerequisites: Git for Windows and curl.
Official Elan install from CMD:

  curl -O --location https://elan.lean-lang.org/elan-init.ps1
  powershell -ExecutionPolicy Bypass -f elan-init.ps1
  del elan-init.ps1

Close and reopen CMD after Elan installation. The project pins Lean 4.33.0 in
`lean-toolchain`; Elan will select/install that toolchain for this project.

Run
---
Extract this archive, open CMD in the extracted folder, then run:

  call run_complete.cmd

On the first run only, Mathlib source/cache must be initialized. On some Windows
systems `lake exe cache get!` returns error 740 unless CMD is elevated. If that
happens, open CMD as Administrator and run `call run_complete.cmd` once. After
Mathlib.olean exists, ordinary non-admin CMD is sufficient for later runs.

Expected final status
---------------------
  BUILD=PASS
  CORE=PASS
  FORWARD=PASS
  REVERSE=PASS
  SPLIT=PASS
  MAIN=PASS
  SORRY=NONE
  AXIOM=NONE
  STATUS=LEAN_ROCQ_MATCH_V0_1_4_PASS

Current abstraction boundary
----------------------------
The generic `Laws M` bundle has been removed. The remaining explicit imported
interfaces correspond to concrete Rocq upstream theorems:
  Scale2Facts                    <-> PHIRH242 + PHIRH243 (v0.24)
  NormalizedDyadicMultiplierFacts <-> PHIRH233 (v0.23)

The KQ tails are literal squares, so PHIRH270/271 are proved directly in Lean.
