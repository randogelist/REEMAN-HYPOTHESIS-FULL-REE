@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title AWPI Phi/RH Lean Rocq-match v0.1.4 native Windows

set "LEANBIN=%USERPROFILE%\.elan\toolchains\leanprover--lean4---v4.33.0\bin"
set "LEANEXE=%LEANBIN%\lean.exe"
set "LAKEEXE=%LEANBIN%\lake.exe"
set "LEAN_NUM_THREADS=1"
set "MATHLIB_NO_CACHE_ON_UPDATE=1"

 echo PACKAGE=AWPI_PHI_RH_LEAN_MATCH_ROCQ_V0_1_4
 echo MODE=NATIVE_WINDOWS_ROCQ_MATCH
 echo LEAN=4.33.0
 echo ROOT=%CD%
 echo.

if not exist "%LEANEXE%" goto no_lean
if not exist "%LAKEEXE%" goto no_lean
where git >nul 2>&1
if errorlevel 1 goto no_git

 echo [0/6] TOOLCHAIN
"%LEANEXE%" --version || goto fail
"%LAKEEXE%" --version || goto fail

if not exist "lake-manifest.json" (
  echo [1/6] LAKE_UPDATE
  "%LAKEEXE%" update || goto update_fail
) else (
  echo [1/6] LAKE_UPDATE=SKIP_MANIFEST_PRESENT
)

if not exist ".lake\packages\mathlib\.lake\build\lib\lean\Mathlib.olean" (
  echo [2/6] MATHLIB_CACHE
  "%LAKEEXE%" exe cache get! || goto cache_fail
) else (
  echo [2/6] MATHLIB_CACHE=READY
)

 echo [3/6] BUILD_SPLIT
"%LAKEEXE%" build AWPI.PhiRH.Split || goto build_fail

 echo [4/6] MAIN_CHECKS
"%LAKEEXE%" env "%LEANEXE%" Main.lean || goto main_fail

 echo [5/6] UNSAFE_TOKEN_SCAN
findstr /S /I /R /C:"\<sorry\>" /C:"\<admit\>" /C:"\<axiom\>" AWPI\*.lean Main.lean >nul 2>&1
if not errorlevel 1 goto scan_fail

 echo [6/6] COMPLETE
 echo BUILD=PASS
 echo CORE=PASS
 echo FORWARD=PASS
 echo REVERSE=PASS
 echo SPLIT=PASS
 echo MAIN=PASS
 echo SORRY=NONE
 echo AXIOM=NONE
 echo STATUS=LEAN_ROCQ_MATCH_V0_1_4_PASS
exit /b 0

:no_lean
echo LEAN=NOT_FOUND
echo EXPECTED=%LEANEXE%
echo STATUS=INSTALL_ELAN_LEAN_4_33_0
exit /b 2
:no_git
echo GIT=NOT_FOUND
echo STATUS=INSTALL_GIT
exit /b 2
:update_fail
echo STATUS=LAKE_UPDATE_FAIL
exit /b 3
:cache_fail
echo STATUS=MATHLIB_CACHE_FAIL
echo NOTE=If Windows reports error 740, rerun this CMD as Administrator once.
exit /b 4
:build_fail
echo STATUS=LEAN_BUILD_FAIL
exit /b 5
:main_fail
echo STATUS=LEAN_MAIN_FAIL
exit /b 6
:scan_fail
echo STATUS=UNSAFE_TOKEN_FOUND
exit /b 7
:fail
echo STATUS=TOOLCHAIN_FAIL
exit /b 8
